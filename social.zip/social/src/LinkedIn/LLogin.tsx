import React, { Component } from "react";
import { LinkedInLoginButton } from "react-social-login-buttons";
import { IResolveParams, LoginSocialLinkedin } from "reactjs-social-login";

export default class LLogin extends Component<{parse:any}> {
  render() {
    return (
      <LoginSocialLinkedin
        client_id={process.env.REACT_APP_LINKEDIN_APP_ID || ""}
        client_secret={process.env.REACT_APP_LINKEDIN_APP_SECRET || ""}
        redirect_uri={process.env.REDIRECT_URI || ""}
        // onLoginStart={onLoginStart}
        onResolve={({ provider, data }: IResolveParams) => {
            console.log(data);
        }}
        onReject={(err: any) => {
          console.log(err);
        }}
      >
        <LinkedInLoginButton />
      </LoginSocialLinkedin>
    );
  }
}
