import { useState } from "react";
import "./App.css";
import FBLogin from "./Facebook/FBLogin";
import GLogin from "./Google/GLogin";
import LLogin from "./LinkedIn/LLogin";
import MLogin from "./Microsoft/MLogin";
import WLogin from "./WhatsApp/WLogin";

function App() {
  const [data, setdata] = useState({
    img: "",
    name: "",
    email: "",
  });
  const parser = (data: any) => {
    setdata({
      img: data.img,
      name: data.name,
      email: data.email,
    });
  };
  const LogOut = () => {
    setdata({
      img: "",
      name: "",
      email: "",
    });
  };
  return (
    <div className="App">
      <div className="social">
        <GLogin parse={parser} />
        <FBLogin parse={parser} />
        <MLogin parse={parser}/>
        <LLogin parse={parser}/>
        {/* <WLogin/> */}
      </div>
      <div className="profile">
        <h4>Profile</h4>
        <img src={data ? data.img : ""} alt="Image" />
        <h5>{data.name}</h5>
        <h5>{data.email}</h5>
        {data.name && <button onClick={LogOut}>Logout</button>}
      </div>
    </div>
  );
}

export default App;
