import React, { Component } from "react";
import { IResolveParams, LoginSocialGoogle } from "reactjs-social-login";
import { GoogleLoginButton } from "react-social-login-buttons";

export default class GLogin extends Component<{ parse: any }> {
  render() {
    return (
      <LoginSocialGoogle
        client_id={process.env.REACT_APP_GOOGLE || ""}
        // onLoginStart={onLoginStart}
        redirect_uri={process.env.REDIRECT_URI}
        scope="openid profile email"
        discoveryDocs="claims_supported"
        access_type="offline"
        onResolve={({ provider, data }: IResolveParams) => {
          console.log(data);
          let obj = {
            img: data ? data.picture : "",
            name: data ? data.name : "",
            email: data ? data.email : "",
          };
          this.props.parse(obj);
        }}
        onReject={(err) => {
          console.log(err);
        }}
      >
        <GoogleLoginButton />
      </LoginSocialGoogle>
    );
  }
}
