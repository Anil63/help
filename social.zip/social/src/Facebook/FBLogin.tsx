import React, { Component } from "react";
import { FacebookLoginButton } from "react-social-login-buttons";
import { IResolveParams, LoginSocialFacebook } from "reactjs-social-login";

export default class FBLogin extends Component<{ parse: any }> {
  render() {
    return (
      <LoginSocialFacebook
        appId={process.env.REACT_APP_FACEBOOK || ""}
        fieldsProfile={
          "id,first_name,last_name,middle_name,name,name_format,picture,short_name,email,gender"
        }
        // onLoginStart={onLoginStart}
        // onLogoutSuccess={onLogoutSuccess}
        redirect_uri={process.env.REDIRECT_URI}
        onResolve={({ provider, data }: IResolveParams) => {
          console.log(provider);
          console.log(data ? data.picture.data.url : "");
          let obj = {
            img: data ? data.picture.data.url : "",
            name: data ? data.name : "",
            email: data ? data.email : "",
          };
          this.props.parse(obj);
        }}
        onReject={(err) => {
          console.log(err);
        }}
      >
        <FacebookLoginButton />
      </LoginSocialFacebook>
    );
  }
}
