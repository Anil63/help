import React, { Component } from "react";
import { MicrosoftLoginButton } from "react-social-login-buttons";
import { IResolveParams, LoginSocialMicrosoft } from "reactjs-social-login";

export default class MLogin extends Component<{parse:any}> {
  render() {
    return (
      <LoginSocialMicrosoft
        client_id={process.env.REACT_APP_MICROSOFT || ""}
        redirect_uri="http://localhost:3000"
        // onLoginStart={onLoginStart}
        onResolve={({ provider, data }: IResolveParams) => {
            console.log(data);
        }}
        onReject={(err: any) => {
          console.log(err);
        }}
      >
        <MicrosoftLoginButton />
      </LoginSocialMicrosoft>
    );
  }
}
