import React, { Component } from "react";
const request = require("request");
const options = {
  method: "POST",
  url: "https://api.ultramsg.com/instance25163/messages/chat",
  headers: { "content-type": "application/x-www-form-urlencoded" },
  form: {
    token: "i0918skk752dbw1k",
    to: "+919624567734",
    body: "WhatsApp API on UltraMsg.com works good",
    priority: "10",
    referenceId: "",
  },
};
export default class WLogin extends Component {
  constructor(prop: {}) {
    super(prop);
  }
  render() {
    request(options, function (error:any, response:any, body:any) {
      if (error) throw new Error(error);

      console.log(body);
    });
    return <div>WLogin</div>;
  }
}
